<div class="main-right">
		<div class="main-right-category">
			<div class="title"><i class="fa fa-list-ul"></i> Danh mục</div>
				<?php gblog_category(); ?>
			</div><!--main-category-->

			<?php get_sidebar(); ?>

		</div><!--main-left-->