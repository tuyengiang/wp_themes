
<div style="clear:left;"></div>
</div><!--website-->
<div style="clear:left;"></div>
<div class="back">
	<i class="fa fa-angle-up"></i>
</div><!--back-->
<?php wp_footer(); ?>
<div class="footer">
	<p>Copyright &copy; <?php echo DATE('Y'); ?> Tuyển Giảng &trade;</p>
	<p>Version: 1.0 (Beta)</p>
</div>

</body>
</html>