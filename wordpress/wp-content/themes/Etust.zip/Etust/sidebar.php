<?php 

 dynamic_sidebar('main-siderbar');